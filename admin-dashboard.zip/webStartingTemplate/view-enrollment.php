<?php
//database connection//
require_once('logics/dbconnection.php');
$sqlFetchStudent=mysqli_query($conn,
    "SELECT * FROM enrollment WHERE no ='".$_GET['id']."'");
while($sqlFetchStudentrecords=mysqli_fetch_array($sqlFetchStudent))
{
    $fullName =$sqlFetchStudentrecords['fullName'];
    $phone =$sqlFetchStudentrecords['phonenumber'];
    $emailaddress =$sqlFetchStudentrecords['emailaddress'];
    $gender=$sqlFetchStudentrecords['gender'];
    $course=$sqlFetchStudentrecords['course'];
    $created_at=$sqlFetchStudentrecords['created_at'];
}

?>
<!DOCTYPE html>
<html>
<?php require_once('includes/headers.php')?>
<body>
	<!-- All our code. write here   -->
	<?php require_once('includes/navbar.php')?>

	<div class="sidebar">
    <?php require_once('includes/sidebar.php')?>

	</div>
	<div class="main-content">
    <!-- to mantain the style -->
		<div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white text-center">
                            <h4 class="card-title">personal information</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item">Full Name: <span class="float-right badge badge-primary"><?php echo$fullName?></span></li>
                                <li class="list-group-item">Email: <span class="float-right badge badge-secondary"><?php echo$emailaddress?></span></li>
                                <li class="list-group-item">Phone number: <span class="float-right badge badge-danger"><?php echo$phone?></span></li>
                            </ul>
                        </div>
		            </div>
                </div> 
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header bg-dark text-white text-center">
                            <h4 class="card-title">other information</h4>
                        </div>
                        <div class="card-body">
                            <ul class="list-group">
                                <li class="list-group-item">gender <span class="float-right badge badge-primary"><?php echo$gender?></span></li>
                                <li class="list-group-item">course <span class="float-right badge badge-secondary"><?php echo$course?></span></li>
                                <li class="list-group-item">created_at <span class="float-right badge badge-danger"><?php echo$created_at?></span></li>
                            </ul>
                    </div>
		        </div>		
	        </div>
        </div>
    </div>
</div>    
	
	<?php require_once('includes/scripts.php')?>
</body>
</html>